"""
chat client
发送请求，得到结果
"""
from socket import *

# 服务端地址
ADDR = ("127.0.0.1",8000)

# 请求进入聊天室 OK FAIL
def login(sock):
    while True:
        name = input("Name:")
        msg = "L " + name  # 根据通信协议整理发送信息
        sock.sendto(msg.encode(),ADDR) # 发送请求
        result,addr = sock.recvfrom(128) # 等待回复
        if result.decode() == 'OK':
            print("您已进入聊天室")
            return
        else:
            print("你的名字太受欢迎了，换一个吧")


def main():
    sock = socket(AF_INET,SOCK_DGRAM)
    login(sock) # 进入聊天室


if __name__ == '__main__':
    main()
